> ### USER
* user_id
* first_name
* middle_name
* username
* password
> ### INVOICE
* invoice_id
* invoice_date
* customer_name
* customer_contact
* customer_adress
* amount_paid
> ### INVOICE_PRODUCT
* invoice_product_id
* invoice_id
* product_id
* quantity
> ### PRODUCT
* product_id
* product_barcode
* product_name
* product_price
* prouct_stock
* category_id
* brand_id
> ### INVENTORY
* inventory_id
* inventory_action
* inventory_quantity
* product_id
* inventory_date
> ### CATEGORY
* category_id
* category_name
> ### BRAND
* brand_id
* brand_name
